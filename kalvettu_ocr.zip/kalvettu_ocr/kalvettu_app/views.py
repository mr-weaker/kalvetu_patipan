import os
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage

from ml_model import predict

def upload_and_predict(request):
    context = {}
    if request.method == "POST" and request.FILES.get("image"):
        image = request.FILES["image"]
        fs = FileSystemStorage()
        filename = fs.save(image.name, image)
        filepath = fs.path(filename)

        try:
            pred = predict.predict_label(filepath)
            context["prediction"] = pred
            context["image_url"] = fs.url(filename)
        except Exception as e:
            context["error"] = str(e)

    return render(request, "upload.html", context)
